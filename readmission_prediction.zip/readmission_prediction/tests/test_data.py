import pandas as pd
import pytest

from readmission.config import FEATURES, ID_COLUMNS, TARGET
from readmission.data import generate_synthetic_data, load_data, save_data


def test_has_expected_columns_and_rows(raw_df):
    assert list(raw_df.columns) == ID_COLUMNS + FEATURES + [TARGET]
    assert len(raw_df) == 1500


def test_target_is_binary_and_imbalanced(raw_df):
    assert set(raw_df[TARGET].unique()) == {0, 1}
    assert 0.12 < raw_df[TARGET].mean() < 0.22


def test_readmission_rate_can_be_tuned():
    df = generate_synthetic_data(2000, seed=3, readmission_rate=0.30)
    assert 0.25 < df[TARGET].mean() < 0.35


def test_same_seed_is_reproducible_and_different_seed_differs():
    a = generate_synthetic_data(500, seed=1)
    b = generate_synthetic_data(500, seed=1)
    c = generate_synthetic_data(500, seed=2)
    pd.testing.assert_frame_equal(a, b)
    assert not a.equals(c)


def test_identifiers_are_unique_and_present(raw_df):
    assert raw_df["patient_id"].is_unique
    assert raw_df["encounter_id"].is_unique
    assert raw_df[ID_COLUMNS].notna().all().all()


def test_some_values_are_missing_but_the_label_never_is(raw_df):
    for col in ["bmi", "hemoglobin", "sodium", "creatinine", "insurance", "a1c_result"]:
        assert raw_df[col].isna().any(), col
    assert raw_df[TARGET].notna().all()


def test_values_are_in_plausible_ranges(raw_df):
    assert raw_df["age"].between(18, 95).all()
    assert (raw_df["length_of_stay"] >= 1).all()
    for col in ["num_procedures", "num_lab_procedures", "num_medications", "num_diagnoses",
                "prior_admissions_12m", "emergency_visits_12m"]:
        assert (raw_df[col] >= 0).all(), col
    assert raw_df["hemoglobin"].dropna().between(6, 18).all()
    assert raw_df["sodium"].dropna().between(120, 155).all()
    assert raw_df["creatinine"].dropna().between(0.4, 8).all()


def test_categorical_columns_have_the_expected_levels(raw_df):
    assert set(raw_df["gender"].unique()) == {"Female", "Male"}
    assert set(raw_df["admission_type"].unique()) == {"Emergency", "Urgent", "Elective"}
    assert set(raw_df["discharge_disposition"].unique()) == {
        "Home", "Home with services", "Skilled nursing", "Rehab"
    }


def test_label_depends_on_visit_history(raw_df):
    """The generator should encode the real-world pattern that frequent visitors return more."""
    frequent = raw_df[raw_df["prior_admissions_12m"] >= 2][TARGET].mean()
    none = raw_df[raw_df["prior_admissions_12m"] == 0][TARGET].mean()
    assert frequent > none + 0.08


@pytest.mark.parametrize(
    "kwargs", [{"n_samples": 5}, {"readmission_rate": 0.0}, {"readmission_rate": 1.2}]
)
def test_rejects_bad_arguments(kwargs):
    with pytest.raises(ValueError):
        generate_synthetic_data(**kwargs)


def test_save_and_load_roundtrip(tmp_path, raw_df):
    path = save_data(raw_df, tmp_path / "nested" / "data.csv")
    loaded = load_data(path)
    assert loaded.shape == raw_df.shape
    assert list(loaded.columns) == list(raw_df.columns)
    assert loaded[TARGET].equals(raw_df[TARGET])


def test_load_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_data(tmp_path / "nope.csv")
