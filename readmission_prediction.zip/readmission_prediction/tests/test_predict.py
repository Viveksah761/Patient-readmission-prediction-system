import json

import joblib
import numpy as np
import pandas as pd
import pytest

from readmission.config import FEATURES
from readmission.evaluate import get_scores
from readmission.predict import (
    load_model_bundle,
    main,
    predict_readmission_risk,
    save_model_bundle,
)

EXPECTED_COLUMNS = ["patient_id", "risk_score", "predicted_readmission", "risk_tier"]


@pytest.fixture(scope="module")
def bundle(trained):
    return load_model_bundle(trained["paths"]["model"])


# --- bundle ---------------------------------------------------------------------
def test_bundle_contains_model_and_metadata(bundle, trained):
    assert bundle["model_name"] == trained["best_model"]
    assert bundle["features"] == FEATURES
    assert bundle["threshold"] == 0.5
    assert bundle["metrics"]["roc_auc"] > 0.5


def test_loaded_model_scores_exactly_like_the_one_in_memory(bundle, trained, split):
    _, X_test, _, _ = split
    in_memory = trained["fitted"][trained["best_model"]]
    assert np.allclose(get_scores(bundle["pipeline"], X_test), get_scores(in_memory, X_test))


def test_loading_a_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_model_bundle(tmp_path / "missing.joblib")


def test_loading_something_that_is_not_a_bundle_raises(tmp_path):
    joblib.dump([1, 2, 3], tmp_path / "list.joblib")
    joblib.dump({"pipeline": object()}, tmp_path / "partial.joblib")
    with pytest.raises(ValueError, match="not a valid"):
        load_model_bundle(tmp_path / "list.joblib")
    with pytest.raises(ValueError, match="not a valid"):
        load_model_bundle(tmp_path / "partial.joblib")


def test_save_bundle_creates_folders(tmp_path, bundle):
    path = save_model_bundle(bundle["pipeline"], "X", tmp_path / "deep" / "dir" / "m.joblib")
    assert load_model_bundle(path)["model_name"] == "X"


# --- scoring --------------------------------------------------------------------
def test_scores_sample_patients(bundle, sample_patients):
    out = predict_readmission_risk(bundle, sample_patients)
    assert list(out.columns) == EXPECTED_COLUMNS
    assert out["patient_id"].tolist() == [900001, 900002, 900003]
    assert out["risk_score"].between(0, 1).all()
    assert set(out["risk_tier"]) <= {"Low", "Moderate", "High"}
    # prediction flag and tier agree: flagged exactly when in the High tier
    assert (out["predicted_readmission"] == (out["risk_tier"] == "High")).all()


def test_sicker_patient_scores_higher_than_healthy_patient(bundle, sample_patients):
    scores = predict_readmission_risk(bundle, sample_patients).set_index("patient_id")["risk_score"]
    # 82-year-old, 4 prior admissions, skilled nursing, low hemoglobin vs 41-year-old elective injury
    assert scores[900001] > scores[900002]


def test_dict_list_and_dataframe_inputs_are_equivalent(bundle, sample_patients):
    from_list = predict_readmission_risk(bundle, sample_patients)
    from_frame = predict_readmission_risk(bundle, pd.DataFrame(sample_patients))
    pd.testing.assert_frame_equal(from_list, from_frame)
    single = predict_readmission_risk(bundle, sample_patients[0])
    assert len(single) == 1
    assert single["risk_score"].iloc[0] == pytest.approx(from_list["risk_score"].iloc[0])


def test_a_bare_pipeline_can_be_used_instead_of_a_bundle(bundle, sample_patients):
    a = predict_readmission_risk(bundle["pipeline"], sample_patients)
    b = predict_readmission_risk(bundle, sample_patients)
    pd.testing.assert_frame_equal(a, b)


def test_unknown_values_are_allowed(bundle, sample_patients):
    patient = dict(sample_patients[2])  # already has null bmi, insurance, hemoglobin
    assert patient["bmi"] is None
    out = predict_readmission_risk(bundle, patient)
    assert np.isfinite(out["risk_score"]).all()


def test_messy_values_are_cleaned_the_same_way_as_in_training(bundle, sample_patients):
    clean = predict_readmission_risk(bundle, sample_patients[0])
    messy = dict(sample_patients[0], age="82", gender="  Female ")
    assert predict_readmission_risk(bundle, messy)["risk_score"].iloc[0] == pytest.approx(
        clean["risk_score"].iloc[0]
    )
    impossible = dict(sample_patients[0], sodium=9999)  # treated as unknown, not trusted
    assert np.isfinite(predict_readmission_risk(bundle, impossible)["risk_score"]).all()


def test_input_index_and_order_are_preserved(bundle, sample_patients):
    df = pd.DataFrame(sample_patients, index=[10, 11, 12])
    out = predict_readmission_risk(bundle, df)
    assert list(out.index) == [10, 11, 12]
    assert out["patient_id"].tolist() == [900001, 900002, 900003]


def test_patients_without_ids_are_still_scored(bundle, sample_patients):
    df = pd.DataFrame(sample_patients).drop(columns=["patient_id"])
    out = predict_readmission_risk(bundle, df)
    assert list(out.columns) == EXPECTED_COLUMNS[1:]
    assert len(out) == 3


def test_threshold_override_changes_who_is_flagged(bundle, sample_patients):
    everyone = predict_readmission_risk(bundle, sample_patients, threshold=0.0)
    nobody = predict_readmission_risk(bundle, sample_patients, threshold=1.0)
    assert everyone["predicted_readmission"].sum() == 3
    assert nobody["predicted_readmission"].sum() == 0


def test_scoring_is_deterministic(bundle, sample_patients):
    pd.testing.assert_frame_equal(
        predict_readmission_risk(bundle, sample_patients),
        predict_readmission_risk(bundle, sample_patients),
    )


# --- validation -----------------------------------------------------------------
def test_missing_feature_column_is_an_error(bundle, sample_patients):
    incomplete = [{k: v for k, v in p.items() if k != "hemoglobin"} for p in sample_patients]
    with pytest.raises(ValueError, match="Missing required column.*hemoglobin"):
        predict_readmission_risk(bundle, incomplete)


def test_misspelled_field_is_an_error_not_silently_unknown(bundle, sample_patients):
    typo = dict(sample_patients[0])
    typo["lenght_of_stay"] = typo.pop("length_of_stay")
    with pytest.raises(ValueError, match="length_of_stay"):
        predict_readmission_risk(bundle, typo)


def test_empty_input_is_an_error(bundle):
    with pytest.raises(ValueError, match="No patients"):
        predict_readmission_risk(bundle, [])
    with pytest.raises(ValueError, match="No patients"):
        predict_readmission_risk(bundle, pd.DataFrame(columns=FEATURES))


def test_wrong_input_type_is_an_error(bundle):
    with pytest.raises(TypeError):
        predict_readmission_risk(bundle, "not a patient")


@pytest.mark.parametrize("bad", [-0.1, 1.5])
def test_threshold_must_be_between_0_and_1(bundle, sample_patients, bad):
    with pytest.raises(ValueError, match="between 0 and 1"):
        predict_readmission_risk(bundle, sample_patients, threshold=bad)


# --- command line ----------------------------------------------------------------
def test_cli_scores_a_json_file(trained, capsys, tmp_path):
    from tests.conftest import EXAMPLES

    out_csv = tmp_path / "scores.csv"
    code = main(["--model", str(trained["paths"]["model"]),
                 "--input", str(EXAMPLES / "sample_patients.json"), "--output", str(out_csv)])
    text = capsys.readouterr().out
    assert code == 0
    assert "Model:" in text and "900001" in text and "not calibrated" in text
    assert len(pd.read_csv(out_csv)) == 3


def test_cli_scores_a_csv_file(trained, capsys, tmp_path, sample_patients):
    csv = tmp_path / "patients.csv"
    pd.DataFrame(sample_patients).to_csv(csv, index=False)
    assert main(["--model", str(trained["paths"]["model"]), "--input", str(csv)]) == 0
    assert "900002" in capsys.readouterr().out


def test_cli_reports_problems_without_a_traceback(trained, capsys, tmp_path):
    model = str(trained["paths"]["model"])
    assert main(["--model", str(tmp_path / "nope.joblib"), "--input", "x.json"]) == 1
    assert "error:" in capsys.readouterr().err

    bad_ext = tmp_path / "patients.txt"
    bad_ext.write_text("hello")
    assert main(["--model", model, "--input", str(bad_ext)]) == 1
    assert "must be .csv or .json" in capsys.readouterr().err

    bad_json = tmp_path / "broken.json"
    bad_json.write_text("{not json")
    assert main(["--model", model, "--input", str(bad_json)]) == 1

    missing_field = tmp_path / "partial.json"
    missing_field.write_text(json.dumps([{"age": 70}]))
    assert main(["--model", model, "--input", str(missing_field)]) == 1
    assert "Missing required column" in capsys.readouterr().err
