import math

import numpy as np
import pytest

from readmission.risk import TIER_ORDER, assign_risk_tier, risk_tier_summary


def test_tier_boundaries():
    scores = [0.0, 0.2999, 0.30, 0.4999, 0.50, 1.0]
    assert list(assign_risk_tier(scores)) == ["Low", "Low", "Moderate", "Moderate", "High", "High"]


def test_custom_cutoffs():
    assert list(assign_risk_tier([0.1, 0.5, 0.9], low_cutoff=0.4, high_cutoff=0.8)) == [
        "Low", "Moderate", "High"
    ]


def test_invalid_cutoffs_and_nan_scores_are_rejected():
    with pytest.raises(ValueError):
        assign_risk_tier([0.5], low_cutoff=0.7, high_cutoff=0.3)
    with pytest.raises(ValueError):
        assign_risk_tier([0.5, np.nan])


def test_summary_counts_and_rates():
    s = risk_tier_summary([0, 1, 1, 0], [0.1, 0.4, 0.9, 0.95]).set_index("risk_tier")
    assert list(s.index) == TIER_ORDER
    assert s.loc["Low", ["patients", "readmitted"]].tolist() == [1, 0]
    assert s.loc["Moderate", ["patients", "readmitted"]].tolist() == [1, 1]
    assert s.loc["High", ["patients", "readmitted"]].tolist() == [2, 1]
    assert s.loc["High", "readmission_rate"] == 0.5
    assert s["share_of_patients"].sum() == pytest.approx(1.0)


def test_an_empty_tier_has_nan_rate_not_a_crash():
    s = risk_tier_summary([1, 0], [0.9, 0.8]).set_index("risk_tier")
    assert s.loc["Low", "patients"] == 0
    assert math.isnan(s.loc["Low", "readmission_rate"])


def test_summary_rejects_length_mismatch():
    with pytest.raises(ValueError):
        risk_tier_summary([0, 1, 1], [0.1, 0.9])
