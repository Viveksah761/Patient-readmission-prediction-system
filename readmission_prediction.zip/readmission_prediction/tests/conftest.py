"""Shared fixtures. Heavy ones (a full training run) are built once per session."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from readmission.data import generate_synthetic_data
from readmission.pipeline import run_training
from readmission.preprocessing import clean_data, split_data, split_features_target

SEED = 7
EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


@pytest.fixture(scope="session")
def raw_df():
    return generate_synthetic_data(n_samples=1500, seed=SEED)


@pytest.fixture(scope="session")
def clean_df(raw_df):
    return clean_data(raw_df)


@pytest.fixture(scope="session")
def split(clean_df):
    """X_train, X_test, y_train, y_test"""
    X, y = split_features_target(clean_df)
    return split_data(X, y, test_size=0.25, seed=SEED)


@pytest.fixture(scope="session")
def trained(tmp_path_factory):
    """One complete (small) training run shared by the end-to-end tests."""
    out = tmp_path_factory.mktemp("training_run")
    result = run_training(
        output_dir=out, n_samples=1500, seed=SEED, cv_folds=3, permutation_repeats=2, verbose=False
    )
    result["output_dir"] = out
    return result


@pytest.fixture(scope="session")
def sample_patients():
    return json.loads((EXAMPLES / "sample_patients.json").read_text())
