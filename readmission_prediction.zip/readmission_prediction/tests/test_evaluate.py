import numpy as np
import pandas as pd
import pytest
from sklearn.exceptions import NotFittedError
from sklearn.utils.validation import check_is_fitted

from readmission.config import FEATURES
from readmission.evaluate import (
    compute_metrics,
    cross_validate_models,
    fit_and_evaluate,
    permutation_feature_importance,
    select_best_model,
)
from readmission.models import get_pipelines

# Hand-checkable case: 3 readmitted, 5 not. At threshold 0.5 the model flags
# patients 1, 2 and 4  ->  TP=2, FN=1, FP=1, TN=4.
Y_TRUE = [1, 1, 1, 0, 0, 0, 0, 0]
SCORES = [0.9, 0.8, 0.2, 0.7, 0.1, 0.1, 0.2, 0.3]


def test_perfect_predictions_score_one():
    m = compute_metrics([0, 0, 1, 1], [0.1, 0.2, 0.8, 0.9])
    for key in ("accuracy", "precision", "recall", "f1", "roc_auc", "specificity"):
        assert m[key] == 1.0
    assert (m["tn"], m["fp"], m["fn"], m["tp"]) == (2, 0, 0, 2)


def test_metrics_match_hand_calculation():
    m = compute_metrics(Y_TRUE, SCORES)
    assert (m["tp"], m["fn"], m["fp"], m["tn"]) == (2, 1, 1, 4)
    assert m["accuracy"] == pytest.approx(6 / 8)
    assert m["precision"] == pytest.approx(2 / 3)
    assert m["recall"] == pytest.approx(2 / 3)
    assert m["f1"] == pytest.approx(2 / 3)
    assert m["specificity"] == pytest.approx(4 / 5)
    assert m["roc_auc"] == pytest.approx(12.5 / 15)  # 12.5 of 15 pos/neg pairs ranked correctly


def test_score_equal_to_threshold_counts_as_positive():
    m = compute_metrics([1, 0], [0.5, 0.49], threshold=0.5)
    assert (m["tp"], m["tn"]) == (1, 1)


def test_higher_threshold_flags_fewer_patients():
    m = compute_metrics(Y_TRUE, SCORES, threshold=0.85)
    assert (m["tp"], m["fn"], m["fp"], m["tn"]) == (1, 2, 0, 5)
    assert m["recall"] == pytest.approx(1 / 3)
    assert m["precision"] == 1.0


def test_no_predicted_positives_gives_zero_precision_without_error():
    m = compute_metrics([0, 1, 0, 1], [0.1, 0.1, 0.1, 0.1])
    assert m["precision"] == 0.0 and m["recall"] == 0.0 and m["f1"] == 0.0
    assert m["roc_auc"] == 0.5  # all scores tied


def test_single_class_gives_nan_auc_but_other_metrics_work():
    m = compute_metrics([0, 0, 0], [0.1, 0.9, 0.2])
    assert np.isnan(m["roc_auc"])
    assert m["accuracy"] == pytest.approx(2 / 3)


@pytest.mark.parametrize(
    "y_true, y_score, threshold",
    [([0, 1], [0.1], 0.5), ([], [], 0.5), ([0, 1], [0.1, 0.9], 1.5), ([0, 1], [0.1, 0.9], -0.1)],
)
def test_invalid_inputs_raise(y_true, y_score, threshold):
    with pytest.raises(ValueError):
        compute_metrics(y_true, y_score, threshold)


def test_cross_validation_reports_every_metric_per_model(split):
    X_train, _, y_train, _ = split
    two = {k: v for k, v in get_pipelines(7).items() if k in ("Logistic Regression", "Decision Tree")}
    cv = cross_validate_models(two, X_train, y_train, cv_folds=3, seed=7)
    assert list(cv["model"]) == ["Logistic Regression", "Decision Tree"]
    for metric in ("roc_auc", "accuracy", "precision", "recall", "f1"):
        assert cv[f"cv_{metric}_mean"].between(0, 1).all()
        assert (cv[f"cv_{metric}_std"] >= 0).all()
    assert (cv["cv_roc_auc_mean"] > 0.55).all()
    assert (cv["fit_time_s"] > 0).all()


def test_select_best_model_picks_highest_cv_auc():
    cv = pd.DataFrame({"model": ["A", "B", "C"], "cv_roc_auc_mean": [0.70, 0.78, 0.74]})
    assert select_best_model(cv) == "B"


def test_select_best_model_rejects_empty_results():
    with pytest.raises(ValueError):
        select_best_model(pd.DataFrame(columns=["model", "cv_roc_auc_mean"]))


def test_fit_and_evaluate_leaves_the_originals_unfitted(split):
    X_train, X_test, y_train, y_test = split
    pipelines = {"Logistic Regression": get_pipelines(7)["Logistic Regression"]}
    fitted, metrics = fit_and_evaluate(pipelines, X_train, y_train, X_test, y_test)
    check_is_fitted(fitted["Logistic Regression"])
    with pytest.raises(NotFittedError):
        check_is_fitted(pipelines["Logistic Regression"])
    assert list(metrics["model"]) == ["Logistic Regression"]
    assert int(metrics[["tn", "fp", "fn", "tp"]].sum(axis=1).iloc[0]) == len(X_test)


def test_permutation_importance_covers_every_feature_and_finds_real_signal(split):
    X_train, X_test, y_train, y_test = split
    pipe = get_pipelines(7)["Logistic Regression"].fit(X_train, y_train)
    imp = permutation_feature_importance(pipe, X_test, y_test, n_repeats=3, seed=1)
    assert sorted(imp["feature"]) == sorted(FEATURES)
    assert imp["importance_mean"].is_monotonic_decreasing
    by_feature = imp.set_index("feature")["importance_mean"]
    # visit history drives the synthetic label; gender has no effect on it
    assert by_feature["prior_admissions_12m"] > by_feature["gender"]
