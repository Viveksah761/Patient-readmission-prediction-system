import numpy as np
import pandas as pd
import pytest

from readmission.config import CATEGORICAL_FEATURES, FEATURES, ID_COLUMNS, NUMERIC_FEATURES, TARGET
from readmission.preprocessing import (
    build_preprocessor,
    clean_data,
    clean_features,
    split_data,
    split_features_target,
    validate_columns,
)


# --- cleaning -----------------------------------------------------------------
def test_clean_data_drops_exact_duplicate_rows(raw_df):
    duplicated = pd.concat([raw_df, raw_df.head(10)], ignore_index=True)
    assert len(clean_data(duplicated)) == len(raw_df)


def test_clean_data_drops_repeated_encounter_ids(raw_df):
    changed = raw_df.head(3).copy()
    changed["age"] = 50  # same encounter, different values: still a duplicate encounter
    out = clean_data(pd.concat([raw_df, changed], ignore_index=True))
    assert len(out) == len(raw_df)
    assert out["encounter_id"].is_unique


def test_clean_data_drops_rows_without_a_label(raw_df):
    df = raw_df.copy()
    df[TARGET] = df[TARGET].astype(float)
    df.loc[df.index[:5], TARGET] = np.nan
    out = clean_data(df)
    assert len(out) == len(raw_df) - 5
    assert out[TARGET].dtype.kind == "i"


def test_clean_data_rejects_labels_other_than_0_and_1(raw_df):
    df = raw_df.copy()
    df.loc[df.index[0], TARGET] = 2
    with pytest.raises(ValueError, match="only 0 and 1"):
        clean_data(df)


def test_missing_required_column_gives_a_clear_error(raw_df):
    with pytest.raises(ValueError, match="Missing required column.*hemoglobin"):
        clean_data(raw_df.drop(columns=["hemoglobin"]))
    with pytest.raises(ValueError, match="Missing required column"):
        validate_columns(raw_df, ["not_a_column"])


def test_clean_features_flags_impossible_numbers_and_text(raw_df):
    df = raw_df.head(5).copy()
    df["age"] = pd.Series([82, -5, 200, "45", "n/a"], index=df.index, dtype=object)
    df["sodium"] = [140, 9999, 140, 140, 140]
    out = clean_features(df)
    assert out["age"].iloc[0] == 82
    assert out["age"].iloc[3] == 45
    assert out["age"].iloc[[1, 2, 4]].isna().all()
    assert out["sodium"].isna().tolist() == [False, True, False, False, False]
    assert out["age"].dtype == float


def test_clean_features_normalises_categorical_text(raw_df):
    df = raw_df.head(5).copy()
    df["gender"] = pd.Series([" Male ", "", None, "Female", np.nan], index=df.index, dtype=object)
    out = clean_features(df)
    assert out["gender"].iloc[0] == "Male"
    assert out["gender"].iloc[3] == "Female"
    assert out["gender"].iloc[[1, 2, 4]].isna().all()


def test_clean_features_keeps_every_row_and_does_not_change_the_input(raw_df):
    df = pd.concat([raw_df.head(20), raw_df.head(20)], ignore_index=True)
    before = df.copy()
    out = clean_features(df)
    assert len(out) == len(df)  # row-preserving: scoring must return one result per patient
    pd.testing.assert_frame_equal(df, before)


# --- feature selection ----------------------------------------------------------
def test_split_features_target_excludes_identifiers_and_label(clean_df):
    X, y = split_features_target(clean_df)
    assert list(X.columns) == FEATURES
    assert not set(ID_COLUMNS) & set(X.columns)
    assert TARGET not in X.columns
    assert y.dtype.kind == "i"
    assert set(y.unique()) <= {0, 1}
    assert len(X) == len(y) == len(clean_df)


# --- transformer ----------------------------------------------------------------
def test_preprocessor_output_is_finite_and_numeric(split):
    X_train, X_test, _, _ = split
    pre = build_preprocessor().fit(X_train)
    out = pre.transform(X_test)
    assert out.shape[0] == len(X_test)
    assert np.isfinite(out).all()
    assert out.shape[1] == len(pre.get_feature_names_out())
    assert out.shape[1] > len(NUMERIC_FEATURES) + len(CATEGORICAL_FEATURES)  # one-hot expanded


def test_numeric_columns_are_standardised_on_training_data(split):
    X_train, _, _, _ = split
    out = build_preprocessor().fit_transform(X_train)
    block = out[:, : len(NUMERIC_FEATURES)]
    assert np.allclose(block.mean(axis=0), 0, atol=1e-6)
    assert np.allclose(block.std(axis=0), 1, atol=1e-6)


def test_missing_values_become_an_unknown_category_or_the_median(split):
    X_train, _, _, _ = split
    pre = build_preprocessor().fit(X_train)
    row = X_train.head(1).copy()
    row["insurance"] = np.nan
    row["hemoglobin"] = np.nan
    out = pre.transform(row)
    assert np.isfinite(out).all()
    names = list(pre.get_feature_names_out())
    assert out[0, names.index("cat__insurance_Unknown")] == 1


def test_unseen_category_is_ignored_not_an_error(split):
    X_train, X_test, _, _ = split
    pre = build_preprocessor().fit(X_train)
    row = X_test.head(1).copy()
    row["insurance"] = "Alien plan"
    out = pre.transform(row)
    names = pre.get_feature_names_out()
    insurance_cols = [i for i, n in enumerate(names) if n.startswith("cat__insurance_")]
    assert insurance_cols
    assert out[0, insurance_cols].sum() == 0


def test_preprocessor_learns_only_from_training_rows(split):
    X_train, _, _, _ = split
    pre = build_preprocessor().fit(X_train)
    imputer = pre.named_transformers_["num"].named_steps["impute"]
    assert np.allclose(imputer.statistics_, X_train[NUMERIC_FEATURES].median().to_numpy())


# --- splitting ------------------------------------------------------------------
def test_split_is_stratified_disjoint_and_complete(clean_df):
    X, y = split_features_target(clean_df)
    X_tr, X_te, y_tr, y_te = split_data(X, y, test_size=0.2, seed=3)
    assert len(X_te) == pytest.approx(0.2 * len(X), abs=1)
    assert abs(y_tr.mean() - y_te.mean()) < 0.01
    assert set(X_tr.index).isdisjoint(X_te.index)
    assert len(X_tr) + len(X_te) == len(X)


def test_split_is_reproducible(clean_df):
    X, y = split_features_target(clean_df)
    a = split_data(X, y, seed=5)[1].index
    b = split_data(X, y, seed=5)[1].index
    c = split_data(X, y, seed=6)[1].index
    assert a.equals(b)
    assert not a.equals(c)
