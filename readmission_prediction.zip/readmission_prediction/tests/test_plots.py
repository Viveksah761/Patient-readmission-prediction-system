import matplotlib.pyplot as plt
import pandas as pd
import pytest

from readmission import plots
from readmission.risk import risk_tier_summary

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _is_png(path) -> bool:
    return path.is_file() and path.read_bytes()[:8] == PNG_SIGNATURE and path.stat().st_size > 2000


def test_text_ink_is_chosen_for_contrast():
    assert plots._text_on("#184f95") == "#ffffff"  # dark blue fill -> white text
    assert plots._text_on("#cde2fb") == plots.INK  # pale blue fill -> near-black text


def test_every_model_has_a_distinct_fixed_colour():
    colours = list(plots.MODEL_COLORS.values())
    assert len(set(colours)) == len(colours) == 5
    assert plots._color("Some other model") == "#2a78d6"  # safe fallback


def test_rounded_bar_draws_nothing_for_non_positive_length():
    fig = plt.figure(figsize=(4, 3), dpi=100)
    ax = fig.add_axes([0.2, 0.2, 0.7, 0.7])
    ax.set_xlim(0, 1)
    ax.set_ylim(-1, 1)
    plots._rounded_bar(ax, 0, 0.0, "#2a78d6")
    plots._rounded_bar(ax, 0, -0.3, "#2a78d6")
    assert len(ax.patches) == 0
    plots._rounded_bar(ax, 0, 0.5, "#2a78d6")
    assert len(ax.patches) == 2  # rounded bar + square cover at the baseline end
    plt.close(fig)


def test_risk_tier_chart_copes_with_empty_tiers(tmp_path):
    tiers = risk_tier_summary([0, 1, 1, 0, 1], [0.9, 0.95, 0.99, 0.8, 0.7])  # only "High" populated
    assert _is_png(plots.plot_risk_tiers(tiers, 0.6, "Test model", tmp_path / "tiers.png"))


def test_confusion_chart_copes_with_an_empty_row(tmp_path):
    metrics = {"tn": 0, "fp": 0, "fn": 3, "tp": 2}  # no actual negatives at all
    assert _is_png(plots.plot_confusion_matrix(metrics, "Test model", 0.5, tmp_path / "cm.png"))


def test_importance_chart_handles_negative_values_and_short_lists(tmp_path):
    imp = pd.DataFrame(
        {"feature": ["age", "gender", "sodium"], "importance_mean": [0.04, 0.0, -0.002],
         "importance_std": [0.01, 0.0, 0.001]}
    )
    assert _is_png(plots.plot_feature_importance(imp, "Gradient Boosting", tmp_path / "imp.png"))


def test_charts_create_missing_output_folders(tmp_path):
    tiers = risk_tier_summary([0, 1, 0, 1], [0.1, 0.4, 0.6, 0.9])
    target = tmp_path / "a" / "b" / "tiers.png"
    assert _is_png(plots.plot_risk_tiers(tiers, 0.5, "Test model", target))
