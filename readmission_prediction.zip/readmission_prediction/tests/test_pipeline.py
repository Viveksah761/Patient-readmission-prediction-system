"""End-to-end tests of the full training run."""

import json

import pandas as pd
import pytest

import train
from readmission.data import generate_synthetic_data, save_data
from readmission.pipeline import run_training

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
MODELS = {"Logistic Regression", "Decision Tree", "Random Forest", "SVM", "Gradient Boosting"}
FIGURES = ["roc_curves", "model_comparison", "confusion_matrix", "risk_tiers", "feature_importance"]


def test_all_artifacts_are_written(trained):
    out = trained["output_dir"]
    for name in ["cv_results.csv", "test_metrics.csv", "risk_tiers.csv", "feature_importance.csv",
                 "report.md", "summary.json", "synthetic_readmission_data.csv", "model/best_model.joblib"]:
        assert (out / name).is_file() and (out / name).stat().st_size > 0, name
    for fig in FIGURES:
        png = out / "figures" / f"{fig}.png"
        assert png.read_bytes()[:8] == PNG_SIGNATURE and png.stat().st_size > 2000, fig


def test_returned_paths_never_overwrite_each_other(trained):
    paths = trained["paths"]
    assert len(set(paths.values())) == len(paths)
    assert paths["risk_tiers"].suffix == ".csv"
    assert paths["figure_risk_tiers"].suffix == ".png"


def test_all_five_models_were_compared(trained):
    assert set(trained["cv_results"]["model"]) == MODELS
    assert set(trained["test_metrics"]["model"]) == MODELS


def test_best_model_is_the_one_with_highest_cv_auc(trained):
    cv = trained["cv_results"]
    assert trained["best_model"] == cv.loc[cv["cv_roc_auc_mean"].idxmax(), "model"]


def test_every_model_beats_chance_on_held_out_data(trained):
    auc = trained["test_metrics"].set_index("model")["roc_auc"]
    assert (auc > 0.55).all(), auc.to_dict()
    assert auc[trained["best_model"]] > 0.65


def test_reported_metrics_are_valid_probabilities(trained):
    tm = trained["test_metrics"]
    for col in ["accuracy", "precision", "recall", "f1", "roc_auc", "specificity"]:
        assert tm[col].between(0, 1).all(), col


def test_confusion_matrix_cells_add_up_to_the_test_set(trained):
    n_test = trained["dataset"]["n_test"]
    assert (trained["test_metrics"][["tn", "fp", "fn", "tp"]].sum(axis=1) == n_test).all()


def test_train_test_split_matches_requested_size(trained):
    d = trained["dataset"]
    assert d["n_train"] + d["n_test"] == d["n_rows"] == 1500
    assert d["n_test"] == pytest.approx(0.2 * d["n_rows"], abs=1)


def test_higher_risk_tiers_really_are_readmitted_more_often(trained):
    rate = trained["risk_tiers"].set_index("risk_tier")["readmission_rate"]
    assert rate["High"] > rate["Low"]


def test_feature_importance_covers_all_raw_features(trained):
    assert len(trained["feature_importance"]) == 19  # 12 numeric + 7 categorical


def test_summary_json_is_valid_and_consistent(trained):
    summary = json.loads((trained["output_dir"] / "summary.json").read_text())
    assert summary["best_model"] == trained["best_model"]
    assert summary["dataset"]["n_rows"] == 1500
    assert len(summary["test_metrics"]) == 5
    assert "scikit-learn" in summary["versions"]


def test_report_explains_results_and_limits(trained):
    text = (trained["output_dir"] / "report.md").read_text()
    assert trained["best_model"] in text
    assert "synthetic" in text.lower()
    assert "not calibrated" in text
    assert "figures/roc_curves.png" in text
    assert "decision-support" in text


def test_same_seed_reproduces_the_same_results(tmp_path):
    kwargs = dict(n_samples=800, seed=5, cv_folds=3, permutation_repeats=2, make_plots=False, verbose=False)
    a = run_training(output_dir=tmp_path / "a", **kwargs)
    b = run_training(output_dir=tmp_path / "b", **kwargs)
    pd.testing.assert_frame_equal(a["test_metrics"], b["test_metrics"])
    pd.testing.assert_frame_equal(a["cv_results"].drop(columns="fit_time_s"),
                                  b["cv_results"].drop(columns="fit_time_s"))
    assert a["best_model"] == b["best_model"]


def test_training_on_a_user_supplied_csv(tmp_path):
    csv = save_data(generate_synthetic_data(800, seed=9), tmp_path / "my_encounters.csv")
    result = run_training(data_path=csv, output_dir=tmp_path / "out", cv_folds=3,
                          permutation_repeats=2, make_plots=False, verbose=False)
    assert "my_encounters.csv" in result["dataset"]["source"]
    assert "data" not in result["paths"]  # nothing synthetic was generated
    assert "synthetic" not in (tmp_path / "out" / "report.md").read_text().lower().split("## how to read")[0]


def test_plots_can_be_skipped(tmp_path):
    run_training(output_dir=tmp_path, n_samples=600, cv_folds=3, permutation_repeats=1,
                 make_plots=False, verbose=False)
    assert not (tmp_path / "figures").exists()
    assert (tmp_path / "model" / "best_model.joblib").is_file()


def test_missing_data_file_is_an_error(tmp_path):
    with pytest.raises(FileNotFoundError):
        run_training(data_path=tmp_path / "nope.csv", output_dir=tmp_path, verbose=False)


def test_too_many_cv_folds_for_the_data_is_an_error(tmp_path):
    with pytest.raises(ValueError):
        run_training(n_samples=60, cv_folds=100, output_dir=tmp_path, make_plots=False, verbose=False)


# --- command line ----------------------------------------------------------------
def test_train_cli_runs_end_to_end(tmp_path, capsys):
    code = train.main(["--n-samples", "600", "--cv-folds", "3", "--no-plots",
                       "--output-dir", str(tmp_path / "cli")])
    assert code == 0
    assert (tmp_path / "cli" / "model" / "best_model.joblib").is_file()
    assert "Selected model" in capsys.readouterr().out


def test_train_cli_reports_errors_without_a_traceback(tmp_path, capsys):
    code = train.main(["--data", str(tmp_path / "missing.csv"), "--output-dir", str(tmp_path)])
    assert code == 1
    assert "error:" in capsys.readouterr().err
