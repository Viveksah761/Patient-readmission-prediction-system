import numpy as np
import pytest
from sklearn.metrics import recall_score, roc_auc_score

from readmission.evaluate import get_scores
from readmission.models import build_pipeline, get_models, get_pipelines

MODEL_NAMES = ["Logistic Regression", "Decision Tree", "Random Forest", "SVM", "Gradient Boosting"]


def test_the_five_required_algorithms_are_available():
    assert list(get_models()) == MODEL_NAMES


@pytest.mark.parametrize("name", MODEL_NAMES)
def test_every_model_compensates_for_class_imbalance(name):
    assert get_models()[name].class_weight in ("balanced", "balanced_subsample")


def test_pipelines_chain_preprocessing_then_model():
    pipe = build_pipeline(get_models()["Logistic Regression"])
    assert [step for step, _ in pipe.steps] == ["preprocess", "model"]


def test_each_call_returns_fresh_independent_objects():
    a, b = get_pipelines(), get_pipelines()
    assert a["Random Forest"] is not b["Random Forest"]
    assert a["Random Forest"].named_steps["model"] is not b["Random Forest"].named_steps["model"]


@pytest.mark.parametrize("name", MODEL_NAMES)
def test_every_model_trains_scores_and_beats_chance(name, split):
    X_train, X_test, y_train, y_test = split
    pipe = get_pipelines(random_state=7)[name].fit(X_train, y_train)
    scores = get_scores(pipe, X_test)
    assert scores.shape == (len(X_test),)
    assert np.isfinite(scores).all()
    assert scores.min() >= 0.0 and scores.max() <= 1.0
    assert set(np.unique(pipe.predict(X_test))) <= {0, 1}
    assert roc_auc_score(y_test, scores) > 0.55


def test_svm_scores_come_from_the_decision_function(split):
    """SVC(probability=True) is deprecated and would re-centre scores on the base rate."""
    X_train, X_test, y_train, _ = split
    pipe = get_pipelines(random_state=7)["SVM"].fit(X_train, y_train)
    # sklearn >= 1.9 reports an unset `probability` as the string "deprecated", so compare to True
    assert pipe.named_steps["model"].probability is not True
    assert not hasattr(pipe, "predict_proba")
    raw = pipe.decision_function(X_test)
    assert np.allclose(get_scores(pipe, X_test), 1 / (1 + np.exp(-raw)))


def test_class_weighting_means_the_model_actually_flags_readmissions(split):
    X_train, X_test, y_train, y_test = split
    pipe = get_pipelines(random_state=7)["Logistic Regression"].fit(X_train, y_train)
    assert recall_score(y_test, pipe.predict(X_test)) > 0.4


def test_same_seed_gives_identical_random_forest(split):
    X_train, X_test, y_train, _ = split
    a = get_pipelines(random_state=11)["Random Forest"].fit(X_train, y_train)
    b = get_pipelines(random_state=11)["Random Forest"].fit(X_train, y_train)
    assert np.allclose(get_scores(a, X_test), get_scores(b, X_test))
