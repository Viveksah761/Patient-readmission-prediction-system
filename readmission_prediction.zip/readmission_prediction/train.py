#!/usr/bin/env python3
"""Train and compare readmission models.

    python train.py                       # synthetic data, everything in ./outputs
    python train.py --data my_data.csv    # your own labelled encounters
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from readmission.config import DECISION_THRESHOLD, RANDOM_STATE
from readmission.pipeline import run_training


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Train 30-day patient readmission classifiers.")
    parser.add_argument("--data", type=Path, help="CSV of labelled encounters (omit to generate synthetic data)")
    parser.add_argument("--n-samples", type=int, default=6000, help="Synthetic rows to generate")
    parser.add_argument("--seed", type=int, default=RANDOM_STATE)
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--cv-folds", type=int, default=5)
    parser.add_argument("--threshold", type=float, default=DECISION_THRESHOLD,
                        help="Score at or above which a patient is predicted to be readmitted")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--no-plots", action="store_true")
    args = parser.parse_args(argv)

    try:
        run_training(
            data_path=args.data,
            output_dir=args.output_dir,
            n_samples=args.n_samples,
            seed=args.seed,
            test_size=args.test_size,
            cv_folds=args.cv_folds,
            threshold=args.threshold,
            make_plots=not args.no_plots,
        )
    except (FileNotFoundError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
