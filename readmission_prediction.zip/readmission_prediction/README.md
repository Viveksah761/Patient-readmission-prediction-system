# Patient Readmission Prediction

A decision-support tool that predicts whether a discharged patient will be **readmitted within 30 days**,
so that high-risk patients can be given extra follow-up care. It is a binary classification pipeline:
clean the data, train five classifiers, compare them with proper metrics, and score new patients.

It does **not** replace clinical judgement; it ranks patients by risk.

## Quick start

```bash
pip install -r requirements.txt

python train.py                 # generate data, train + compare 5 models, write ./outputs   (~15 s)
python -m pytest                # run the test suite                                          (~30 s)
python predict.py --model outputs/model/best_model.joblib --input examples/sample_patients.json
```

`train.py` writes everything to `outputs/`: `report.md` (start here), CSV tables, `figures/*.png`,
`summary.json` and the saved model `model/best_model.joblib`.

## Results (synthetic data, 6,000 patients, 16.9% readmitted)

Models were compared by 5-fold cross-validation on the 80% training split, and the winner was chosen
by cross-validated ROC-AUC. All five were then scored once on the untouched 20% test split (1,200 patients)
at a score threshold of 0.50:

| Model | ROC-AUC | Recall | Precision | F1 | Accuracy |
|---|---|---|---|---|---|
| **Logistic Regression** (selected) | **0.735** | 0.634 | 0.290 | 0.398 | 0.677 |
| Random Forest | 0.729 | 0.252 | 0.440 | 0.321 | 0.820 |
| SVM | 0.720 | 0.550 | 0.287 | 0.377 | 0.694 |
| Gradient Boosting | 0.713 | 0.540 | 0.305 | 0.390 | 0.716 |
| Decision Tree | 0.686 | 0.762 | 0.236 | 0.360 | 0.544 |

The selected model turns scores into risk tiers that separate patients well on the test set:

| Risk tier | Patients | Actually readmitted |
|---|---|---|
| Low (score < 0.30) | 340 | 3.5% |
| Moderate (0.30 to 0.50) | 418 | 14.8% |
| High (score >= 0.50) | 442 | 29.0% |

Top drivers: prior admissions in the last 12 months, age, hemoglobin, admission type, primary diagnosis.

How to read the table: accuracy is misleading when only ~17% of patients are readmitted. Random Forest has the
best accuracy (0.82) but catches only 25% of readmissions at this threshold; Logistic Regression catches 63%.
For "who needs extra care", recall and ROC-AUC matter more.

## How it works

| Step | Where | What |
|---|---|---|
| Data | `readmission/data.py` | Synthetic encounter data (demographics, visit history, diagnoses, labs, medications, length of stay, procedures) with realistic gaps. Or bring your own CSV. |
| Cleaning | `preprocessing.py` | Drops duplicate rows/encounters and unlabelled rows, turns impossible values (age -5, sodium 9999, "n/a") into missing, trims text. Identifier columns are excluded from the features. |
| Preprocessing | `preprocessing.py` | Median-impute + standardise numeric columns; impute ("Unknown") + one-hot encode categorical ones. Lives *inside* each model pipeline, so nothing leaks from the test set or across CV folds. |
| Models | `models.py` | Logistic Regression, Decision Tree, Random Forest, SVM (RBF), Gradient Boosting (histogram-based). All use class weights to cope with the imbalance. |
| Evaluation | `evaluate.py` | Accuracy, precision, recall, F1, ROC-AUC, confusion matrix, specificity; stratified CV; permutation importance. |
| Risk tiers | `risk.py` | Low / Moderate / High, plus the observed readmission rate in each tier. |
| Scoring | `predict.py` | Loads the saved model and scores patients from JSON/CSV. |
| Figures | `plots.py` | ROC curves, model comparison, confusion matrix, risk tiers, feature importance. |

## Using your own data

```bash
python train.py --data my_encounters.csv
```

The CSV needs the columns in `readmission/config.py`: 12 numeric features, 7 categorical features and the
0/1 label `readmitted_30d` (`patient_id` / `encounter_id` are optional and ignored for modelling). Edit
`config.py` to change the feature list. Useful options: `--threshold`, `--cv-folds`, `--test-size`,
`--seed`, `--output-dir`, `--no-plots`.

To score new patients, every feature key must be present (use `null` when a value is unknown). A misspelled
field name is an error rather than being silently treated as unknown.

## Tests

`python -m pytest` runs 117 tests in about 30 seconds:

- **data**: columns, reproducibility, ranges, missing values, label depends on visit history, bad arguments
- **preprocessing**: duplicates, bad labels, impossible values, whitespace, scaling, unseen categories, no train/test leakage, stratified split
- **models**: all five algorithms train, score in [0, 1], beat chance, are class-weighted and reproducible
- **evaluate**: metrics checked against a hand-computed confusion matrix, thresholds, edge cases, CV, model selection
- **risk, plots**: tier boundaries, empty tiers, chart edge cases
- **predict**: model save/load round trip, input validation, messy input, CLI
- **pipeline**: full end-to-end run, artifacts, reproducibility, user CSV, CLI errors

## Limitations (please read)

- **The data is synthetic.** No real patient data is included, so these numbers show that the pipeline works,
  not how it would perform in a hospital. Logistic Regression wins partly because the synthetic labels were
  generated from a logistic rule; on real data the ranking of models may differ. Validate on real,
  de-identified records before drawing any clinical conclusion.
- **Scores are not calibrated probabilities.** Class weighting makes them rank patients well, but a score of
  0.5 does not mean a 50% chance of readmission.
- **Fixed 0.50 threshold.** Models are compared at one threshold, which favours some over others (see Random Forest).
  Lower it with `--threshold` to catch more readmissions at the cost of more false alarms.
- **Rows are treated as independent patients.** Real data often has several encounters per patient; split
  by patient before training so the same person is never in both train and test.
- **The saved model is a pickle** (`.joblib`). Only load model files you created yourself.
