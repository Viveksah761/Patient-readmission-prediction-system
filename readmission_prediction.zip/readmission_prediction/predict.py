#!/usr/bin/env python3
"""Score patients with a trained model.

    python predict.py --model outputs/model/best_model.joblib --input examples/sample_patients.json
"""

import sys

from readmission.predict import main

if __name__ == "__main__":
    sys.exit(main())
