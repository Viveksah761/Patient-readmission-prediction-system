"""Synthetic patient-encounter data and CSV helpers.

No real patient data ships with this project, so ``generate_synthetic_data``
builds a realistic stand-in: the columns mirror the kind of fields found in
hospital encounter records, the readmission label depends on them through a
known (noisy) rule, and some values are deliberately left missing. Real data
can be used instead by passing a CSV with the same columns to ``train.py``.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .config import CATEGORICAL_FEATURES, FEATURES, ID_COLUMNS, RANDOM_STATE, TARGET

# How much each category shifts the log-odds of readmission.
_DIAGNOSIS_EFFECT = {
    "Circulatory": 0.35,
    "Respiratory": 0.30,
    "Diabetes": 0.25,
    "Digestive": 0.0,
    "Injury": -0.30,
    "Other": 0.0,
}
_ADMISSION_EFFECT = {"Emergency": 0.30, "Urgent": 0.05, "Elective": -0.40}
_INSURANCE_EFFECT = {"Medicare": 0.0, "Medicaid": 0.25, "Private": -0.10, "Self-pay": 0.15}
_DISPOSITION_EFFECT = {
    "Home": 0.0,
    "Home with services": 0.20,
    "Skilled nursing": 0.55,
    "Rehab": 0.35,
}
_A1C_LABELS = ["Normal", "High (>7)", "High (>8)", "Not tested"]
_A1C_EFFECT = {"Normal": 0.0, "High (>7)": 0.10, "High (>8)": 0.30, "Not tested": 0.0}
_MED_CHANGE_EFFECT = {"No": 0.0, "Yes": 0.10}

# Fraction of values blanked out per column, to exercise imputation.
_MISSING_RATES = {
    "bmi": 0.10,
    "hemoglobin": 0.06,
    "sodium": 0.05,
    "creatinine": 0.08,
    "insurance": 0.03,
    "a1c_result": 0.02,
}


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def _effect(values: np.ndarray, mapping: dict[str, float]) -> np.ndarray:
    return pd.Series(values).map(mapping).to_numpy(dtype=float)


def _calibrate_intercept(base_logit: np.ndarray, target_rate: float) -> float:
    """Find the intercept that makes the mean predicted risk equal ``target_rate``."""
    lo, hi = -15.0, 15.0
    for _ in range(100):
        mid = (lo + hi) / 2.0
        if _sigmoid(base_logit + mid).mean() > target_rate:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2.0


def generate_synthetic_data(
    n_samples: int = 6000,
    seed: int = RANDOM_STATE,
    readmission_rate: float = 0.17,
) -> pd.DataFrame:
    """Create a synthetic hospital-discharge dataset.

    Each row is one discharged patient. ``readmitted_30d`` is 1 for roughly
    ``readmission_rate`` of rows, so the classes are imbalanced as in real life.
    """
    if n_samples < 10:
        raise ValueError("n_samples must be at least 10")
    if not 0.0 < readmission_rate < 1.0:
        raise ValueError("readmission_rate must be strictly between 0 and 1")

    rng = np.random.default_rng(seed)
    n = n_samples

    # --- demographics and encounter context --------------------------------
    age = np.clip(np.round(rng.normal(65, 16, n)), 18, 95)
    gender = rng.choice(["Female", "Male"], n)
    bmi = np.clip(rng.normal(29, 6, n), 16, 55).round(1)
    admission_type = rng.choice(["Emergency", "Urgent", "Elective"], n, p=[0.55, 0.25, 0.20])
    diagnosis = rng.choice(
        list(_DIAGNOSIS_EFFECT), n, p=[0.28, 0.16, 0.18, 0.12, 0.10, 0.16]
    )
    insurance = rng.choice(
        list(_INSURANCE_EFFECT), n, p=[0.46, 0.18, 0.30, 0.06]
    )
    disposition = rng.choice(
        list(_DISPOSITION_EFFECT), n, p=[0.60, 0.15, 0.17, 0.08]
    )

    # --- utilisation and treatment counts -----------------------------------
    length_of_stay = np.clip(
        np.round(1 + rng.gamma(2.2, 1.9, n) + 0.02 * (age - 65) + 0.8 * (admission_type == "Emergency")),
        1,
        30,
    )
    num_diagnoses = np.clip(
        np.round(rng.normal(5 + 0.03 * (age - 50) + 0.1 * length_of_stay, 1.8)), 1, 16
    )
    num_procedures = np.clip(rng.poisson(1.1 + 0.4 * (admission_type == "Elective")), 0, 6)
    num_lab_procedures = np.clip(np.round(rng.normal(35 + 2 * length_of_stay, 12)), 1, 120)
    num_medications = np.clip(
        np.round(rng.normal(10 + 0.8 * num_diagnoses + 0.4 * length_of_stay, 4)), 1, 40
    )
    prior_admissions = np.clip(
        rng.poisson(
            0.3 + 0.01 * np.maximum(age - 40, 0) + 0.15 * np.isin(diagnosis, ["Circulatory", "Diabetes"])
        ),
        0,
        10,
    )
    emergency_visits = np.clip(rng.poisson(0.2 + 0.25 * prior_admissions), 0, 8)

    # --- lab values ----------------------------------------------------------
    hemoglobin = np.clip(rng.normal(13.6 - 0.012 * age - 0.08 * num_diagnoses, 1.5), 6, 18).round(1)
    sodium = np.clip(rng.normal(139, 3.2, n), 120, 155).round(0)
    creatinine = np.clip(np.exp(rng.normal(0.004 * (age - 50), 0.35)), 0.4, 8).round(2)

    a1c = np.where(
        diagnosis == "Diabetes",
        rng.choice(_A1C_LABELS, n, p=[0.20, 0.30, 0.35, 0.15]),
        rng.choice(_A1C_LABELS, n, p=[0.15, 0.10, 0.05, 0.70]),
    )
    medication_change = rng.choice(["No", "Yes"], n, p=[0.55, 0.45])

    # --- label: noisy logistic rule over the true (pre-missing) values -------
    base_logit = (
        0.025 * (age - 65)
        + 0.45 * prior_admissions
        + 0.35 * emergency_visits
        + 0.06 * length_of_stay
        + 0.08 * (num_diagnoses - 6)
        + 0.015 * (num_medications - 14)
        + 0.05 * num_procedures
        + 0.18 * (12.5 - hemoglobin)
        + 0.25 * (creatinine - 1.0)
        + _effect(diagnosis, _DIAGNOSIS_EFFECT)
        + _effect(admission_type, _ADMISSION_EFFECT)
        + _effect(insurance, _INSURANCE_EFFECT)
        + _effect(disposition, _DISPOSITION_EFFECT)
        + _effect(a1c, _A1C_EFFECT)
        + _effect(medication_change, _MED_CHANGE_EFFECT)
        + rng.normal(0, 0.6, n)
    )
    intercept = _calibrate_intercept(base_logit, readmission_rate)
    readmitted = (rng.random(n) < _sigmoid(base_logit + intercept)).astype(int)

    df = pd.DataFrame(
        {
            "patient_id": rng.permutation(n) + 100_000,
            "encounter_id": rng.permutation(n) + 5_000_000,
            "age": age.astype(int),
            "gender": gender,
            "bmi": bmi,
            "admission_type": admission_type,
            "primary_diagnosis": diagnosis,
            "insurance": insurance,
            "discharge_disposition": disposition,
            "length_of_stay": length_of_stay.astype(int),
            "num_procedures": num_procedures.astype(int),
            "num_lab_procedures": num_lab_procedures.astype(int),
            "num_medications": num_medications.astype(int),
            "num_diagnoses": num_diagnoses.astype(int),
            "prior_admissions_12m": prior_admissions.astype(int),
            "emergency_visits_12m": emergency_visits.astype(int),
            "hemoglobin": hemoglobin,
            "sodium": sodium,
            "creatinine": creatinine,
            "a1c_result": a1c,
            "medication_change": medication_change,
            TARGET: readmitted,
        }
    )

    for col in CATEGORICAL_FEATURES:
        df[col] = df[col].astype(object)

    # --- realistic gaps ----------------------------------------------------
    for col, rate in _MISSING_RATES.items():
        mask = rng.random(n) < rate
        if col in CATEGORICAL_FEATURES:
            df.loc[mask, col] = np.nan
        else:
            df[col] = df[col].astype(float)
            df.loc[mask, col] = np.nan

    # Column order: identifiers, features, target.
    return df[ID_COLUMNS + FEATURES + [TARGET]]


def save_data(df: pd.DataFrame, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return path


def load_data(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Data file not found: {path}")
    return pd.read_csv(path)
