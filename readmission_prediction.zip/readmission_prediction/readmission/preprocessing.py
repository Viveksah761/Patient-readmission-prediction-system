"""Cleaning, feature selection and the scikit-learn preprocessing transformer.

The transformer returned by ``build_preprocessor`` is meant to live *inside* a
``Pipeline`` together with the model, so imputation values, scaling statistics
and one-hot categories are learned from training rows only (no test leakage,
also inside cross-validation).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .config import (
    CATEGORICAL_FEATURES,
    FEATURES,
    NUMERIC_FEATURES,
    RANDOM_STATE,
    TARGET,
    VALID_RANGES,
)


def validate_columns(df: pd.DataFrame, columns: list[str]) -> None:
    """Raise a clear error if any of ``columns`` is absent from ``df``."""
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {', '.join(missing)}")


def _normalize_categorical(series: pd.Series) -> pd.Series:
    """Trim whitespace and map None / pd.NA / empty strings to NaN."""
    s = series.astype(object)
    s = s.map(lambda v: v.strip() if isinstance(v, str) else v)
    s = s.where(s.notna(), np.nan)
    return s.replace("", np.nan)


def clean_features(df: pd.DataFrame) -> pd.DataFrame:
    """Row-preserving cleaning of the feature columns.

    * numeric columns are coerced to numbers (``"n/a"`` becomes NaN);
    * numbers outside their plausible clinical range become NaN;
    * categorical columns are trimmed and blanks become NaN.

    Used for both training data and new patients to score.
    """
    validate_columns(df, FEATURES)
    out = df.copy()
    for col in NUMERIC_FEATURES:
        values = pd.to_numeric(out[col], errors="coerce").astype(float)
        low, high = VALID_RANGES[col]
        out[col] = values.where(values.between(low, high))
    for col in CATEGORICAL_FEATURES:
        out[col] = _normalize_categorical(out[col])
    return out


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean a labelled training table.

    Drops duplicate rows/encounters and rows without a label, checks the label
    is 0/1, and applies :func:`clean_features`.
    """
    validate_columns(df, FEATURES + [TARGET])
    out = df.drop_duplicates()
    if "encounter_id" in out.columns:
        out = out.drop_duplicates(subset="encounter_id", keep="first")

    out = out.copy()
    out[TARGET] = pd.to_numeric(out[TARGET], errors="coerce")
    out = out.dropna(subset=[TARGET])
    if not out[TARGET].isin([0, 1]).all():
        raise ValueError(f"Target column '{TARGET}' must contain only 0 and 1")
    out[TARGET] = out[TARGET].astype(int)

    return clean_features(out).reset_index(drop=True)


def split_features_target(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Return model inputs ``X`` (identifier columns excluded) and label ``y``."""
    validate_columns(df, FEATURES + [TARGET])
    return df[FEATURES].copy(), df[TARGET].astype(int).copy()


def build_preprocessor() -> ColumnTransformer:
    """Impute + scale numeric columns, impute + one-hot encode categorical ones."""
    numeric = Pipeline(
        [
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]
    )
    categorical = Pipeline(
        [
            ("impute", SimpleImputer(strategy="constant", fill_value="Unknown")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )
    return ColumnTransformer(
        [
            ("num", numeric, NUMERIC_FEATURES),
            ("cat", categorical, CATEGORICAL_FEATURES),
        ]
    )


def split_data(
    X: pd.DataFrame,
    y: pd.Series,
    test_size: float = 0.2,
    seed: int = RANDOM_STATE,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Stratified train/test split so both parts keep the readmission rate."""
    return train_test_split(X, y, test_size=test_size, stratify=y, random_state=seed)
