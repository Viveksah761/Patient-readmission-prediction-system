"""Turn model scores into Low / Moderate / High risk tiers."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .config import DECISION_THRESHOLD, LOW_RISK_CUTOFF

TIER_ORDER = ["Low", "Moderate", "High"]


def assign_risk_tier(
    scores,
    low_cutoff: float = LOW_RISK_CUTOFF,
    high_cutoff: float = DECISION_THRESHOLD,
) -> np.ndarray:
    """Map scores to tiers: ``< low_cutoff`` Low, ``>= high_cutoff`` High, else Moderate.

    The scores are model outputs trained with class weighting, so they rank
    patients well but are *not* calibrated probabilities of readmission.
    """
    scores = np.asarray(scores, dtype=float)
    if np.isnan(scores).any():
        raise ValueError("scores must not contain NaN")
    if low_cutoff > high_cutoff:
        raise ValueError("low_cutoff must not exceed high_cutoff")
    return np.where(
        scores >= high_cutoff,
        "High",
        np.where(scores >= low_cutoff, "Moderate", "Low"),
    )


def risk_tier_summary(y_true, scores) -> pd.DataFrame:
    """Observed readmission rate inside each predicted risk tier.

    This is the practical test of a decision-support tool: patients in the High
    tier should really be readmitted more often than those in the Low tier.
    """
    y_true = np.asarray(y_true)
    tiers = assign_risk_tier(scores)
    if y_true.shape != tiers.shape:
        raise ValueError("y_true and scores must have the same length")

    rows = []
    for tier in TIER_ORDER:
        in_tier = tiers == tier
        patients = int(in_tier.sum())
        readmitted = int(y_true[in_tier].sum()) if patients else 0
        rows.append(
            {
                "risk_tier": tier,
                "patients": patients,
                "share_of_patients": patients / len(y_true),
                "readmitted": readmitted,
                "readmission_rate": readmitted / patients if patients else float("nan"),
            }
        )
    return pd.DataFrame(rows)
