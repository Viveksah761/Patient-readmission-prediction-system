"""Save/load a trained model and score new patients (library and command line).

Example::

    python -m readmission.predict --model outputs/model/best_model.joblib \
        --input examples/sample_patients.json
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd
import sklearn
from sklearn.pipeline import Pipeline

from .config import DECISION_THRESHOLD, FEATURES, ID_COLUMNS, LOW_RISK_CUTOFF
from .evaluate import get_scores
from .preprocessing import clean_features, validate_columns
from .risk import assign_risk_tier

_BUNDLE_KEYS = {"pipeline", "model_name", "threshold", "features"}


def save_model_bundle(
    pipeline: Pipeline,
    model_name: str,
    path: str | Path,
    threshold: float = DECISION_THRESHOLD,
    metrics: dict | None = None,
) -> Path:
    """Persist the fitted pipeline together with the metadata needed to use it."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    bundle = {
        "pipeline": pipeline,
        "model_name": model_name,
        "threshold": threshold,
        "features": list(FEATURES),
        "metrics": metrics or {},
        "sklearn_version": sklearn.__version__,
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    joblib.dump(bundle, path)
    return path


def load_model_bundle(path: str | Path) -> dict:
    """Load a bundle written by :func:`save_model_bundle`.

    Only load files you created yourself: joblib files are pickles and can run
    code when opened.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Model file not found: {path}")
    bundle = joblib.load(path)
    if not isinstance(bundle, dict) or not _BUNDLE_KEYS <= bundle.keys():
        raise ValueError(f"{path} is not a valid readmission model bundle")
    return bundle


def _to_frame(patients) -> pd.DataFrame:
    if isinstance(patients, pd.DataFrame):
        df = patients.copy()
    elif isinstance(patients, dict):
        df = pd.DataFrame([patients])
    elif isinstance(patients, (list, tuple)):
        df = pd.DataFrame(list(patients))
    else:
        raise TypeError("patients must be a DataFrame, a dict, or a list of dicts")
    if len(df) == 0:
        raise ValueError("No patients to score")
    return df


def predict_readmission_risk(
    model: dict | Pipeline,
    patients: pd.DataFrame | dict | list[dict],
    threshold: float | None = None,
) -> pd.DataFrame:
    """Score patients and return one row per patient.

    ``model`` is a bundle from :func:`load_model_bundle` or a fitted pipeline.
    Every feature column must be present in the input (use null for an unknown
    value) so a misspelled field name fails loudly instead of being silently
    treated as "unknown".

    Returns ``risk_score`` (0-1, higher = more likely readmitted),
    ``predicted_readmission`` (0/1) and ``risk_tier`` (Low/Moderate/High), plus
    any identifier columns found in the input.
    """
    if isinstance(model, dict):
        pipeline = model["pipeline"]
        default_threshold = model.get("threshold", DECISION_THRESHOLD)
    else:
        pipeline, default_threshold = model, DECISION_THRESHOLD
    cutoff = default_threshold if threshold is None else threshold
    if not 0.0 <= cutoff <= 1.0:
        raise ValueError("threshold must be between 0 and 1")

    df = _to_frame(patients)
    validate_columns(df, FEATURES)
    X = clean_features(df)[FEATURES]
    scores = get_scores(pipeline, X)

    out = df[[c for c in ID_COLUMNS if c in df.columns]].copy()
    out["risk_score"] = scores
    out["predicted_readmission"] = (scores >= cutoff).astype(int)
    out["risk_tier"] = assign_risk_tier(
        scores, low_cutoff=min(LOW_RISK_CUTOFF, cutoff), high_cutoff=cutoff
    )
    return out


def _read_patients(path: Path):
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".json":
        return json.loads(path.read_text())
    raise ValueError("Input file must be .csv or .json")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Score patients for 30-day readmission risk.")
    parser.add_argument("--model", type=Path, required=True, help="Path to best_model.joblib")
    parser.add_argument("--input", type=Path, required=True, help="Patients as .json (object or list) or .csv")
    parser.add_argument("--output", type=Path, help="Optional CSV path for the results")
    args = parser.parse_args(argv)

    try:
        bundle = load_model_bundle(args.model)
        patients = _read_patients(args.input)
        result = predict_readmission_risk(bundle, patients)
    except (FileNotFoundError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print(f"Model: {bundle['model_name']}  (decision threshold {bundle['threshold']:.2f})")
    print(result.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print("\nDecision support only: scores rank patients by risk; they are not calibrated "
          "probabilities and do not replace clinical judgement.")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        result.to_csv(args.output, index=False)
        print(f"Saved results to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
