"""Metrics, cross-validation and model selection."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    make_scorer,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.inspection import permutation_importance
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline

from .config import DECISION_THRESHOLD, RANDOM_STATE


def get_scores(pipeline: Pipeline, X: pd.DataFrame) -> np.ndarray:
    """Model score for the positive class (readmitted), in [0, 1].

    Uses ``predict_proba`` when the model has it. Otherwise (the SVM) it squashes
    the decision function through a sigmoid, so 0.5 is the model's own boundary.
    """
    if hasattr(pipeline, "predict_proba"):
        return pipeline.predict_proba(X)[:, 1]
    raw = pipeline.decision_function(X)
    return 1.0 / (1.0 + np.exp(-raw))


def compute_metrics(
    y_true, y_score, threshold: float = DECISION_THRESHOLD
) -> dict[str, float]:
    """Accuracy, precision, recall, F1, ROC-AUC and the confusion matrix cells.

    ``y_score`` are scores in [0, 1]; scores >= ``threshold`` count as predicted
    readmissions. ROC-AUC is NaN when ``y_true`` contains only one class.
    """
    y_true = np.asarray(y_true)
    y_score = np.asarray(y_score, dtype=float)
    if y_true.shape != y_score.shape:
        raise ValueError("y_true and y_score must have the same length")
    if y_true.size == 0:
        raise ValueError("Cannot compute metrics on empty input")
    if not 0.0 <= threshold <= 1.0:
        raise ValueError("threshold must be between 0 and 1")

    y_pred = (y_score >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    specificity = tn / (tn + fp) if (tn + fp) else float("nan")
    roc_auc = roc_auc_score(y_true, y_score) if len(np.unique(y_true)) == 2 else float("nan")

    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc,
        "specificity": specificity,
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def cross_validate_models(
    pipelines: dict[str, Pipeline],
    X: pd.DataFrame,
    y: pd.Series,
    cv_folds: int = 5,
    seed: int = RANDOM_STATE,
) -> pd.DataFrame:
    """Stratified k-fold cross-validation on the training data, one row per model."""
    cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=seed)
    scoring = {
        "roc_auc": "roc_auc",
        "accuracy": "accuracy",
        "precision": make_scorer(precision_score, zero_division=0),
        "recall": make_scorer(recall_score, zero_division=0),
        "f1": make_scorer(f1_score, zero_division=0),
    }
    rows = []
    for name, pipe in pipelines.items():
        result = cross_validate(pipe, X, y, cv=cv, scoring=scoring)
        row = {"model": name, "fit_time_s": float(np.mean(result["fit_time"]))}
        for metric in scoring:
            scores = result[f"test_{metric}"]
            row[f"cv_{metric}_mean"] = float(np.mean(scores))
            row[f"cv_{metric}_std"] = float(np.std(scores))
        rows.append(row)
    return pd.DataFrame(rows)


def fit_and_evaluate(
    pipelines: dict[str, Pipeline],
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    threshold: float = DECISION_THRESHOLD,
) -> tuple[dict[str, Pipeline], pd.DataFrame]:
    """Fit a fresh copy of each pipeline on train, score it on the held-out test set."""
    fitted: dict[str, Pipeline] = {}
    rows = []
    for name, pipe in pipelines.items():
        model = clone(pipe).fit(X_train, y_train)
        fitted[name] = model
        metrics = compute_metrics(y_test, get_scores(model, X_test), threshold)
        rows.append({"model": name, **metrics})
    return fitted, pd.DataFrame(rows)


def permutation_feature_importance(
    pipeline: Pipeline,
    X: pd.DataFrame,
    y: pd.Series,
    n_repeats: int = 5,
    seed: int = RANDOM_STATE,
) -> pd.DataFrame:
    """How much ROC-AUC drops when each *original* column is shuffled.

    Works for any model (including SVM) and reports importance per raw feature
    rather than per one-hot column. Sorted most to least important.
    """
    result = permutation_importance(
        pipeline, X, y, scoring="roc_auc", n_repeats=n_repeats, random_state=seed, n_jobs=1
    )
    return (
        pd.DataFrame(
            {
                "feature": X.columns,
                "importance_mean": result.importances_mean,
                "importance_std": result.importances_std,
            }
        )
        .sort_values("importance_mean", ascending=False)
        .reset_index(drop=True)
    )


def select_best_model(cv_results: pd.DataFrame) -> str:
    """Name of the model with the highest mean cross-validated ROC-AUC.

    Chosen on training-set CV only, so the test set stays an unbiased final check.
    """
    if cv_results.empty:
        raise ValueError("cv_results is empty")
    return str(cv_results.loc[cv_results["cv_roc_auc_mean"].idxmax(), "model"])
