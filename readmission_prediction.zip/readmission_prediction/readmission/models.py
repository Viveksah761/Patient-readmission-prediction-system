"""The five candidate classifiers, each wrapped with the shared preprocessor.

Readmissions are the minority class (~17%), so every model is told to weight
the classes inversely to their frequency. Otherwise they would score well on
accuracy by simply predicting "not readmitted" for everyone.
"""

from __future__ import annotations

from sklearn.base import BaseEstimator
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from .config import RANDOM_STATE
from .preprocessing import build_preprocessor


def get_models(random_state: int = RANDOM_STATE) -> dict[str, BaseEstimator]:
    """Unfitted estimators keyed by display name."""
    return {
        "Logistic Regression": LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=random_state
        ),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=5,
            min_samples_leaf=30,
            class_weight="balanced",
            random_state=random_state,
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            min_samples_leaf=5,
            class_weight="balanced_subsample",
            n_jobs=-1,
            random_state=random_state,
        ),
        # No `probability=True` (deprecated in scikit-learn 1.9, and Platt scaling
        # would re-centre scores on the 17% base rate). Scores come from the
        # class-weighted decision function instead; see evaluate.get_scores.
        "SVM": SVC(kernel="rbf", C=1.0, class_weight="balanced", random_state=random_state),
        # Histogram-based gradient boosting (scikit-learn's fast implementation).
        "Gradient Boosting": HistGradientBoostingClassifier(
            max_iter=200,
            learning_rate=0.05,
            max_leaf_nodes=15,
            l2_regularization=1.0,
            class_weight="balanced",
            random_state=random_state,
        ),
    }


def build_pipeline(estimator: BaseEstimator) -> Pipeline:
    """Preprocessing followed by the given classifier."""
    return Pipeline([("preprocess", build_preprocessor()), ("model", estimator)])


def get_pipelines(random_state: int = RANDOM_STATE) -> dict[str, Pipeline]:
    return {name: build_pipeline(est) for name, est in get_models(random_state).items()}
