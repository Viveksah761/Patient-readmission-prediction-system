"""Static PNG figures for the training report.

Chart conventions: one fixed colour per model (colour follows the model, never
its rank), 4px rounded data-ends on bars that grow from a square baseline,
hairline solid gridlines, values labelled at the bar tip, text always in ink
colours (never the series colour). Colours come from a palette that passes a
colour-vision-deficiency check; the legend plus the CSV/markdown tables written
next to the figures give a non-colour way to read every value.
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # file output only, no display needed

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, to_rgb  # noqa: E402
from matplotlib.patches import FancyBboxPatch, Rectangle  # noqa: E402
from matplotlib.ticker import MaxNLocator  # noqa: E402
from sklearn.metrics import roc_curve  # noqa: E402

from .config import DECISION_THRESHOLD, LOW_RISK_CUTOFF  # noqa: E402
from .evaluate import get_scores  # noqa: E402

# --- design tokens (light surface) -----------------------------------------
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK_2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"

# Categorical slots 1-5, fixed order. Identity is tied to the model.
MODEL_COLORS = {
    "Logistic Regression": "#2a78d6",
    "Decision Tree": "#eb6834",
    "Random Forest": "#1baf7a",
    "SVM": "#eda100",
    "Gradient Boosting": "#e87ba4",
}
_FALLBACK_COLOR = "#2a78d6"

# Ordinal blue ramp for ordered risk tiers (steps 250 / 400 / 600).
TIER_COLORS = {"Low": "#86b6ef", "Moderate": "#3987e5", "High": "#184f95"}
# Sequential blue ramp (steps 100 / 400 / 600) for the confusion-matrix shading.
_SEQUENTIAL = LinearSegmentedColormap.from_list("blue_seq", ["#cde2fb", "#3987e5", "#184f95"])

DPI_BASE = 100  # figure size is laid out at 100 dpi, saved at twice that
SAVE_DPI = 200


def _color(model: str) -> str:
    return MODEL_COLORS.get(model, _FALLBACK_COLOR)


# --- small helpers ------------------------------------------------------------
def _luminance(hex_color: str) -> float:
    def lin(c: float) -> float:
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

    r, g, b = (lin(c) for c in to_rgb(hex_color))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _text_on(background: str) -> str:
    """White or near-black ink, whichever contrasts more with the fill."""
    lb = _luminance(background)

    def contrast(fg: str) -> float:
        lf = _luminance(fg)
        return (max(lb, lf) + 0.05) / (min(lb, lf) + 0.05)

    return max(("#ffffff", INK), key=contrast)


def _new_figure(width: float, height: float) -> plt.Figure:
    return plt.figure(figsize=(width, height), dpi=DPI_BASE, facecolor=SURFACE)


def _header(fig: plt.Figure, title: str, subtitle: str) -> None:
    fig.text(0.03, 0.975, title, fontsize=13, fontweight="bold", color=INK, ha="left", va="top")
    wrapped = textwrap.fill(subtitle, width=int(fig.get_figwidth() * 12), break_on_hyphens=False)
    fig.text(0.03, 0.975 - 0.32 / fig.get_figheight(), wrapped, fontsize=9, color=INK_2,
             ha="left", va="top", linespacing=1.35)


def _style_axes(ax: plt.Axes) -> None:
    ax.set_facecolor(SURFACE)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(AXIS)
        ax.spines[side].set_linewidth(1.0)
    ax.tick_params(axis="both", length=0, labelcolor=INK_2, labelsize=9)
    ax.set_axisbelow(True)


def _hairline_grid(ax: plt.Axes, axis: str) -> None:
    ax.grid(axis=axis, color=GRID, linewidth=0.8, linestyle="-")


def _px_per_unit(ax: plt.Axes) -> tuple[float, float]:
    box = ax.get_window_extent()
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    return box.width / abs(x1 - x0), box.height / abs(y1 - y0)


def _rounded_bar(ax: plt.Axes, center: float, length: float, color: str, *, horizontal: bool = True,
                 thickness_px: float = 18, radius_px: float = 4) -> None:
    """A bar that grows from a square baseline and ends in a rounded (4px) tip.

    Axis limits must be set before calling, so pixel sizes can be converted.
    """
    if length <= 0:
        return
    ppx, ppy = _px_per_unit(ax)
    if horizontal:
        width, height = length, thickness_px / ppy
        x0, y0 = 0.0, center - height / 2
    else:
        width, height = thickness_px / ppx, length
        x0, y0 = center - width / 2, 0.0
    rx = min(radius_px / ppx, width / 2, height * ppy / ppx / 2)  # radius in x-data units
    ax.add_patch(FancyBboxPatch(
        (x0, y0), width, height, boxstyle=f"round,pad=0,rounding_size={rx}",
        mutation_aspect=ppx / ppy, facecolor=color, edgecolor="none", linewidth=0,
    ))
    # Cover the rounded corners at the baseline end so that end stays square.
    if horizontal:
        ax.add_patch(Rectangle((x0, y0), min(rx * 1.02, width), height, facecolor=color,
                               edgecolor="none", linewidth=0))
    else:
        ry = rx * ppx / ppy
        ax.add_patch(Rectangle((x0, y0), width, min(ry * 1.02, height), facecolor=color,
                               edgecolor="none", linewidth=0))


def _finish(fig: plt.Figure, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=SAVE_DPI, facecolor=SURFACE)
    plt.close(fig)
    return path


# --- figures --------------------------------------------------------------------
def plot_roc_curves(fitted: dict, X_test: pd.DataFrame, y_test, test_metrics: pd.DataFrame,
                    path: str | Path) -> Path:
    """ROC curve for every model on the held-out test set."""
    fig = _new_figure(6.2, 6.2)
    _header(fig, "ROC curves on the held-out test set",
            "Recall against false positive rate at every score threshold. The legend lists each "
            "model's test ROC-AUC; the grey diagonal is chance.")
    ax = fig.add_axes([0.13, 0.10, 0.82, 0.72])
    _style_axes(ax)
    _hairline_grid(ax, "both")
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    ax.plot([0, 1], [0, 1], color=AXIS, linewidth=1.0, zorder=1)
    auc = test_metrics.set_index("model")["roc_auc"]
    for name in auc.sort_values(ascending=False).index:
        fpr, tpr, _ = roc_curve(y_test, get_scores(fitted[name], X_test))
        ax.plot(fpr, tpr, color=_color(name), linewidth=1.5, solid_capstyle="round",
                solid_joinstyle="round", label=f"{name}  (AUC {auc[name]:.3f})", zorder=3)

    ticks = [0, 0.2, 0.4, 0.6, 0.8, 1.0]
    ax.set_xticks(ticks)
    ax.set_yticks(ticks)
    ax.set_xticklabels([f"{t:g}" for t in ticks])
    ax.set_yticklabels([f"{t:g}" for t in ticks])
    ax.set_xlabel("False positive rate", fontsize=9, color=INK_2, labelpad=6)
    ax.set_ylabel("True positive rate (recall)", fontsize=9, color=INK_2, labelpad=6)
    ax.legend(loc="lower right", frameon=False, fontsize=9, labelcolor=INK, handlelength=1.8)
    return _finish(fig, path)


_PANELS = [("roc_auc", "ROC-AUC"), ("recall", "Recall"), ("precision", "Precision"),
           ("f1", "F1 score"), ("accuracy", "Accuracy")]


def plot_model_comparison(test_metrics: pd.DataFrame, best_model: str, path: str | Path,
                          threshold: float = DECISION_THRESHOLD) -> Path:
    """Small multiples: one panel per metric, models in the same order in every panel."""
    df = test_metrics.sort_values("roc_auc", ascending=False).reset_index(drop=True)
    n = len(df)
    fig = _new_figure(12, 1.5 + 0.55 * n)
    _header(fig, "Model comparison on the held-out test set",
            f"Models ordered by ROC-AUC. Recall, precision, F1 and accuracy use a score threshold of "
            f"{threshold:.2f}. The bold name is the model chosen by cross-validation.")

    left, gap, right = 0.15, 0.022, 0.015
    width = (1 - left - right - gap * (len(_PANELS) - 1)) / len(_PANELS)
    for i, (column, label) in enumerate(_PANELS):
        ax = fig.add_axes([left + i * (width + gap), 0.13, width, 0.60])
        _style_axes(ax)
        ax.set_xlim(0, 1.28)
        ax.set_ylim(-0.6, n - 0.4)
        _hairline_grid(ax, "x")
        ax.set_xticks([0, 0.5, 1])
        ax.set_xticklabels(["0", "0.5", "1"])
        ax.set_title(label, loc="left", fontsize=10, color=INK, pad=8)
        ax.set_yticks(range(n))
        ax.set_yticklabels(list(df["model"][::-1]) if i == 0 else [])
        if i == 0:
            for tick in ax.get_yticklabels():
                if tick.get_text() == best_model:
                    tick.set_fontweight("bold")
                    tick.set_color(INK)
        for rank, row in df.iterrows():
            y = n - 1 - rank
            value = float(row[column])
            _rounded_bar(ax, y, value, _color(row["model"]))
            ax.text(value + 0.025, y, f"{value:.3f}", va="center", ha="left", fontsize=8.5, color=INK)
    return _finish(fig, path)


def plot_confusion_matrix(metrics: dict, model_name: str, threshold: float, path: str | Path) -> Path:
    """2x2 confusion matrix, shaded by the share of each actual class."""
    tn, fp, fn, tp = (int(round(float(metrics[k]))) for k in ("tn", "fp", "fn", "tp"))
    fig = _new_figure(6.4, 6.0)
    _header(fig, f"Confusion matrix: {model_name}",
            f"Held-out test set at a score threshold of {threshold:.2f}. Shading shows the share of "
            "each actual class that landed in the cell.")
    ax = fig.add_axes([1.5 / 6.4, 0.55 / 6.0, 3.9 / 6.4, 3.9 / 6.0])
    ax.set_facecolor(SURFACE)
    ax.set_xlim(0, 2)
    ax.set_ylim(0, 2)
    ax.set_axis_off()
    ppx, ppy = _px_per_unit(ax)
    gap_x, gap_y = 2 / ppx, 2 / ppy  # 2px surface gap between cells

    cells = [  # (column, row from top, label, count, row total, row name)
        (0, 0, "True negatives", tn, tn + fp, "not readmitted"),
        (1, 0, "False positives", fp, tn + fp, "not readmitted"),
        (0, 1, "False negatives", fn, fn + tp, "readmitted"),
        (1, 1, "True positives", tp, fn + tp, "readmitted"),
    ]
    for col, row, label, count, total, row_name in cells:
        share = count / total if total else 0.0
        fill = matplotlib.colors.to_hex(_SEQUENTIAL(share))
        ink = _text_on(fill)
        y_low = 1 - row  # row 0 is the top cell
        ax.add_patch(Rectangle((col + gap_x / 2, y_low + gap_y / 2), 1 - gap_x, 1 - gap_y,
                               facecolor=fill, edgecolor="none", linewidth=0))
        cx, cy = col + 0.5, y_low + 0.5
        ax.text(cx, cy + 0.24, label, ha="center", va="center", fontsize=9, color=ink)
        ax.text(cx, cy, f"{count:,}", ha="center", va="center", fontsize=20, fontweight="bold", color=ink)
        ax.text(cx, cy - 0.24, f"{share:.1%} of {row_name}", ha="center", va="center", fontsize=8.5, color=ink)

    for col, name in enumerate(("not readmitted", "readmitted")):
        ax.text(col + 0.5, 2.05, f"Predicted\n{name}", ha="center", va="bottom", fontsize=9, color=INK_2)
    for row, name in enumerate(("not readmitted", "readmitted")):
        ax.text(-0.04, 1.5 - row, f"Actual\n{name}", ha="right", va="center", fontsize=9, color=INK_2)
    return _finish(fig, path)


def plot_risk_tiers(tiers: pd.DataFrame, overall_rate: float, model_name: str, path: str | Path) -> Path:
    """Observed readmission rate inside each predicted risk tier."""
    fig = _new_figure(5.4, 5.2)
    _header(fig, "Readmission rate by predicted risk tier",
            f"{model_name} on the held-out test set. A useful tool puts clearly more readmissions "
            "in the High tier than in the Low tier.")
    ax = fig.add_axes([0.14, 0.17, 0.82, 0.60])
    _style_axes(ax)
    top = max(float(tiers["readmission_rate"].max(skipna=True)), overall_rate) * 1.2
    ax.set_xlim(-0.6, 2.6)
    ax.set_ylim(0, top)
    _hairline_grid(ax, "y")
    ticks = [t for t in MaxNLocator(5).tick_values(0, top) if 0 <= t <= top]
    ax.set_yticks(ticks)
    ax.set_yticklabels([f"{t:.0%}" for t in ticks])

    cutoffs = {
        "Low": f"score < {LOW_RISK_CUTOFF:.2f}",
        "Moderate": f"{LOW_RISK_CUTOFF:.2f} to {DECISION_THRESHOLD:.2f}",
        "High": f"score >= {DECISION_THRESHOLD:.2f}",
    }
    labels = []
    for i, row in tiers.reset_index(drop=True).iterrows():
        rate = row["readmission_rate"]
        if pd.notna(rate):
            _rounded_bar(ax, i, float(rate), TIER_COLORS[row["risk_tier"]], horizontal=False, thickness_px=24)
            ax.text(i, float(rate) + top * 0.02, f"{rate:.1%}", ha="center", va="bottom", fontsize=9.5,
                    fontweight="bold", color=INK)
        else:
            ax.text(i, top * 0.04, "no patients", ha="center", va="bottom", fontsize=9, color=MUTED)
        labels.append(f"{row['risk_tier']}\n{cutoffs[row['risk_tier']]}\nn = {int(row['patients']):,}")
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels)

    ax.axhline(overall_rate, color=INK_2, linewidth=1.0, zorder=2)
    ax.text(-0.6, overall_rate + top * 0.015, f"Test-set average {overall_rate:.1%}", ha="left", va="bottom",
            fontsize=8.5, color=INK_2)
    ax.set_ylabel("Observed readmission rate", fontsize=9, color=INK_2, labelpad=6)
    return _finish(fig, path)


def plot_feature_importance(importance: pd.DataFrame, model_name: str, path: str | Path,
                            top_n: int = 10) -> Path:
    """Top features by permutation importance (drop in test ROC-AUC when shuffled)."""
    top = importance.head(top_n).reset_index(drop=True)
    n = len(top)
    fig = _new_figure(7.2, 1.7 + 0.42 * n)
    _header(fig, f"What drives the predictions: {model_name}",
            "Permutation importance on the held-out test set: how far ROC-AUC falls when one "
            "feature's values are shuffled. Larger means the model leans on it more.")
    ax = fig.add_axes([0.25, 0.13, 0.70, 0.66])
    _style_axes(ax)
    peak = max(float(top["importance_mean"].max()), 1e-6)
    ax.set_xlim(0, peak * 1.22)
    ax.set_ylim(-0.6, n - 0.4)
    _hairline_grid(ax, "x")
    ax.xaxis.set_major_locator(MaxNLocator(4))
    ax.set_yticks(range(n))
    ax.set_yticklabels([name.replace("_", " ") for name in top["feature"][::-1]])
    for rank, row in top.iterrows():
        y = n - 1 - rank
        value = float(row["importance_mean"])
        _rounded_bar(ax, y, max(value, 0.0), _color(model_name))
        ax.text(max(value, 0.0) + peak * 0.02, y, f"{value:.3f}", va="center", ha="left", fontsize=8.5,
                color=INK)
    ax.set_xlabel("Drop in ROC-AUC when shuffled", fontsize=9, color=INK_2, labelpad=6)
    return _finish(fig, path)
