"""End-to-end training run: data -> cleaning -> CV -> held-out test -> artifacts."""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn

from .config import DECISION_THRESHOLD, RANDOM_STATE
from .data import generate_synthetic_data, load_data, save_data
from .evaluate import (
    cross_validate_models,
    fit_and_evaluate,
    get_scores,
    permutation_feature_importance,
    select_best_model,
)
from .models import get_pipelines
from .predict import save_model_bundle
from .preprocessing import clean_data, split_data, split_features_target
from .risk import risk_tier_summary


def _markdown_table(df: pd.DataFrame) -> str:
    """Small dependency-free DataFrame -> GitHub markdown table."""

    def fmt(value) -> str:
        if isinstance(value, (float, np.floating)):
            return "n/a" if np.isnan(value) else f"{value:.3f}"
        return str(value)

    lines = [
        "| " + " | ".join(df.columns) + " |",
        "|" + "|".join("---" for _ in df.columns) + "|",
    ]
    lines += ["| " + " | ".join(fmt(v) for v in row) + " |" for row in df.itertuples(index=False)]
    return "\n".join(lines)


def _write_report(path: Path, info: dict, cv: pd.DataFrame, test: pd.DataFrame, best: str,
                  tiers: pd.DataFrame, importance: pd.DataFrame, figures: dict[str, str]) -> None:
    best_row = test.set_index("model").loc[best]
    cv_view = pd.DataFrame(
        {
            "Model": cv["model"],
            "CV ROC-AUC": [f"{m:.3f} ± {s:.3f}" for m, s in zip(cv["cv_roc_auc_mean"], cv["cv_roc_auc_std"])],
            "CV recall": cv["cv_recall_mean"],
            "CV precision": cv["cv_precision_mean"],
            "CV F1": cv["cv_f1_mean"],
        }
    )
    test_view = test[["model", "roc_auc", "recall", "precision", "f1", "accuracy", "specificity"]].rename(
        columns={
            "model": "Model", "roc_auc": "ROC-AUC", "recall": "Recall", "precision": "Precision",
            "f1": "F1", "accuracy": "Accuracy", "specificity": "Specificity",
        }
    )
    tier_view = tiers.assign(share_of_patients=(tiers["share_of_patients"] * 100).round(1)).rename(
        columns={
            "risk_tier": "Risk tier", "patients": "Patients", "share_of_patients": "% of patients",
            "readmitted": "Readmitted", "readmission_rate": "Observed readmission rate",
        }
    )
    imp_view = importance.head(10).rename(
        columns={"feature": "Feature", "importance_mean": "ROC-AUC drop", "importance_std": "Std"}
    )

    figure_lines = "\n".join(f"![{name}]({rel})" for name, rel in figures.items())
    text = f"""# Patient readmission prediction: results

**Data:** {info['source']} - {info['n_rows']:,} patients after cleaning,
{info['readmission_rate']:.1%} readmitted within 30 days
({info['n_train']:,} train / {info['n_test']:,} held-out test, stratified split, seed {info['seed']}).

**Selected model:** {best} (highest cross-validated ROC-AUC on the training set).
On the held-out test set it reaches ROC-AUC {best_row['roc_auc']:.3f}, recall {best_row['recall']:.3f},
precision {best_row['precision']:.3f} and F1 {best_row['f1']:.3f} at a decision threshold of {info['threshold']:.2f}.

## Cross-validation ({info['cv_folds']}-fold, training set only)

{_markdown_table(cv_view)}

## Held-out test set

{_markdown_table(test_view)}

## Risk tiers for {best} (test set)

{_markdown_table(tier_view)}

## Most influential features (permutation importance, test set)

{_markdown_table(imp_view)}

## Figures

{figure_lines}

## How to read this

* Readmissions are the minority class, so accuracy alone is misleading; recall and ROC-AUC matter more
  for finding patients who need extra follow-up. Models were trained with class weights to reflect that.
* Scores rank patients by risk. They are **not calibrated probabilities**.
* {info['caveat']}
* This is a decision-support aid. It does not replace clinical judgement.
"""
    path.write_text(text, encoding="utf-8")


def run_training(
    data_path: str | Path | None = None,
    output_dir: str | Path = "outputs",
    n_samples: int = 6000,
    seed: int = RANDOM_STATE,
    test_size: float = 0.2,
    cv_folds: int = 5,
    threshold: float = DECISION_THRESHOLD,
    permutation_repeats: int = 5,
    make_plots: bool = True,
    verbose: bool = True,
) -> dict:
    """Run the full workflow and write all artifacts into ``output_dir``.

    Uses ``data_path`` if given (a CSV with the project's columns), otherwise
    generates synthetic data. Returns the key results as a dict.
    """
    log = print if verbose else (lambda *args, **kwargs: None)
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths: dict[str, Path] = {}
    t0 = time.perf_counter()

    # 1. data ---------------------------------------------------------------
    if data_path is None:
        raw = generate_synthetic_data(n_samples=n_samples, seed=seed)
        paths["data"] = save_data(raw, out_dir / "synthetic_readmission_data.csv")
        source = "synthetic data (generated by this project)"
        caveat = ("The data is synthetic, so the metrics show the pipeline works, not how it would "
                  "perform on real patients. Re-run with --data on real encounters before drawing "
                  "any clinical conclusion.")
    else:
        raw = load_data(data_path)
        source = f"CSV file {Path(data_path).name}"
        caveat = "Results reflect the supplied dataset and should be validated before clinical use."

    df = clean_data(raw)
    X, y = split_features_target(df)
    X_train, X_test, y_train, y_test = split_data(X, y, test_size=test_size, seed=seed)
    log(f"Data: {len(raw):,} rows -> {len(df):,} after cleaning; "
        f"readmission rate {y.mean():.1%}; train {len(X_train):,} / test {len(X_test):,}")

    # 2. cross-validate every model on the training set ----------------------
    pipelines = get_pipelines(seed)
    log(f"Cross-validating {len(pipelines)} models ({cv_folds}-fold)...")
    cv_results = cross_validate_models(pipelines, X_train, y_train, cv_folds=cv_folds, seed=seed)
    best = select_best_model(cv_results)

    # 3. fit on train, evaluate once on the untouched test set ---------------
    log("Fitting on the training set and scoring the held-out test set...")
    fitted, test_metrics = fit_and_evaluate(pipelines, X_train, y_train, X_test, y_test, threshold)
    best_pipeline = fitted[best]
    best_scores = get_scores(best_pipeline, X_test)
    tiers = risk_tier_summary(y_test, best_scores)
    importance = permutation_feature_importance(
        best_pipeline, X_test, y_test, n_repeats=permutation_repeats, seed=seed
    )

    # 4. save tables, model and report ---------------------------------------
    paths["cv_results"] = out_dir / "cv_results.csv"
    cv_results.to_csv(paths["cv_results"], index=False)
    paths["test_metrics"] = out_dir / "test_metrics.csv"
    test_metrics.to_csv(paths["test_metrics"], index=False)
    paths["risk_tiers"] = out_dir / "risk_tiers.csv"
    tiers.to_csv(paths["risk_tiers"], index=False)
    paths["feature_importance"] = out_dir / "feature_importance.csv"
    importance.to_csv(paths["feature_importance"], index=False)

    best_test = test_metrics.set_index("model").loc[best].to_dict()
    paths["model"] = save_model_bundle(
        best_pipeline, best, out_dir / "model" / "best_model.joblib",
        threshold=threshold, metrics={k: float(v) for k, v in best_test.items()},
    )

    # 5. figures ---------------------------------------------------------------
    figures: dict[str, str] = {}
    if make_plots:
        from . import plots  # imported lazily so matplotlib is optional for scoring

        fig_dir = out_dir / "figures"
        fig_dir.mkdir(exist_ok=True)
        jobs = {
            "roc_curves": lambda p: plots.plot_roc_curves(fitted, X_test, y_test, test_metrics, p),
            "model_comparison": lambda p: plots.plot_model_comparison(test_metrics, best, p, threshold),
            "confusion_matrix": lambda p: plots.plot_confusion_matrix(best_test, best, threshold, p),
            "risk_tiers": lambda p: plots.plot_risk_tiers(tiers, float(y_test.mean()), best, p),
            "feature_importance": lambda p: plots.plot_feature_importance(importance, best, p),
        }
        for name, draw in jobs.items():
            target = fig_dir / f"{name}.png"
            draw(target)
            paths[f"figure_{name}"] = target
            figures[name.replace("_", " ").capitalize()] = f"figures/{name}.png"

    info = {
        "source": source,
        "n_rows": int(len(df)),
        "readmission_rate": float(y.mean()),
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "seed": seed,
        "threshold": threshold,
        "cv_folds": cv_folds,
        "caveat": caveat,
    }
    paths["report"] = out_dir / "report.md"
    _write_report(paths["report"], info, cv_results, test_metrics, best, tiers, importance, figures)

    summary = {
        "best_model": best,
        "dataset": {k: v for k, v in info.items() if k != "caveat"},
        "cv_results": cv_results.to_dict(orient="records"),
        "test_metrics": test_metrics.to_dict(orient="records"),
        "risk_tiers": tiers.to_dict(orient="records"),
        "versions": {"scikit-learn": sklearn.__version__, "pandas": pd.__version__, "numpy": np.__version__},
        "runtime_seconds": round(time.perf_counter() - t0, 1),
    }
    paths["summary"] = out_dir / "summary.json"
    paths["summary"].write_text(json.dumps(summary, indent=2, default=float), encoding="utf-8")

    log(f"\nSelected model (best CV ROC-AUC): {best}")
    log(test_metrics.set_index("model").loc[:, ["roc_auc", "recall", "precision", "f1", "accuracy"]]
        .round(3).to_string())
    log(f"\nArtifacts written to {out_dir.resolve()}  ({summary['runtime_seconds']}s)")

    return {
        "best_model": best,
        "cv_results": cv_results,
        "test_metrics": test_metrics,
        "risk_tiers": tiers,
        "feature_importance": importance,
        "fitted": fitted,
        "paths": paths,
        "dataset": info,
    }
