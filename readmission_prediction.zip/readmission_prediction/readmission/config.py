"""Shared constants for the patient readmission prediction project."""

from __future__ import annotations

RANDOM_STATE = 42

# Target: 1 = patient was readmitted within 30 days of discharge, 0 = not.
TARGET = "readmitted_30d"

# Identifiers carry no clinical signal (and would let a model memorise
# patients), so they are dropped before modelling.
ID_COLUMNS = ["patient_id", "encounter_id"]

NUMERIC_FEATURES = [
    "age",
    "bmi",
    "length_of_stay",
    "num_procedures",
    "num_lab_procedures",
    "num_medications",
    "num_diagnoses",
    "prior_admissions_12m",
    "emergency_visits_12m",
    "hemoglobin",
    "sodium",
    "creatinine",
]

CATEGORICAL_FEATURES = [
    "gender",
    "admission_type",
    "primary_diagnosis",
    "insurance",
    "discharge_disposition",
    "a1c_result",
    "medication_change",
]

FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

# Plausible clinical ranges. Values outside are treated as data-entry errors
# and turned into missing values (then imputed) rather than trusted.
VALID_RANGES = {
    "age": (0, 120),
    "bmi": (10, 80),
    "length_of_stay": (0, 365),
    "num_procedures": (0, 50),
    "num_lab_procedures": (0, 500),
    "num_medications": (0, 100),
    "num_diagnoses": (0, 30),
    "prior_admissions_12m": (0, 100),
    "emergency_visits_12m": (0, 100),
    "hemoglobin": (3, 25),
    "sodium": (100, 180),
    "creatinine": (0.1, 20),
}

# Score at or above this marks a patient as "predicted to be readmitted".
DECISION_THRESHOLD = 0.5
# Score below this is "Low" risk; between this and DECISION_THRESHOLD is "Moderate".
LOW_RISK_CUTOFF = 0.30
